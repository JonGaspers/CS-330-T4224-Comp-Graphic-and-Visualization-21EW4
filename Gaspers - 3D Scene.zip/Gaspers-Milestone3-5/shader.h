#pragma once
#include <string>
#include <fstream>
#include <GL/glew.h>

#include <array>
#include <iostream>
class shader
{
public:
	shader(const std::string& filename, GLuint shaderType);
	GLuint shaderIndex;
private:

};

