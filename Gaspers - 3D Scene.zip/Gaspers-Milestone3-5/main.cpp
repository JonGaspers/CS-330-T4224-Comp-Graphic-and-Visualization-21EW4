/*
*   Name: Jonathon Gaspers
*   Date: April 16, 2021
*   Course: CS330-T4224
*   Description: This program is to show a recreation of a 2d image in 3d space using OpenGL. I also added in camera controls as listed below and in the controls.txt file. 
*   Controls: WASD: forward, left, back, and right camera movement
*             Q: Lower camera
*             E: Raise camera
*             P: Perspective view
*             O: Orthographic view
*             F1/F2: Show wireframe or fill modes
*             Mouse Scroll forward: Increase movement speed
*             Mose Scroll backward: Decrease movement speed
*/

#include <iostream>
#include <filesystem>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION

#include "stb_image.h"
#include <string>
#include "shader.h"
#include "camera.h"
#include "model.h"
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>


namespace {

    //window constants
    constexpr auto WINDOW_WIDTH = 800;
    constexpr auto WINDOW_HEIGHT = 600;
    constexpr auto WINDOW_TITLE = std::string_view("Gaspers CS340 Final Project");

    //camera parameters
    //auto cameraTranslation = glm::vec3(-2, 1.5, -2);
    auto originTranslation = glm::vec3(0, 0, 0);
    auto cameraPos = glm::vec3(0, 0, 3);
    auto cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    auto cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    auto gDeltaTime = 0.0f; //time between frames
    auto gLastFrame = 0.0f;

    //texture id
    GLuint gtextureId;

    //UV scale
    glm::vec2 UVScale(1.0f, 1.0f);

    //instantiate camera object from camera.h
    Camera gCam(cameraPos);
    auto lastX = WINDOW_WIDTH / 2.0f;
    auto lastY = WINDOW_HEIGHT / 2.0f;
    auto FirstMouse = true;
    auto viewSwitch = false; //false = perspective, true = orthographic

    //cube and light color
    glm::vec4 objectColor(1.0f, 0.2f, 0.0f, 1.0f);
    glm::vec3 lightColor(1.0f, 1.0f, 1.0f);
    glm::vec4 object2Color(1.0f, 0.0f, 0.0f, 1.0f);
    glm::vec3 light2Color(1.0f, 0.5f, 0.5f);

    //light pos and scale
    glm::vec3 lightPos(8.0f, 3.5f, 8.0f);
    glm::vec3 light2Pos(-8.0f, 5.5f, -8.0f);
    glm::vec3 lightScale(0.5f);

    auto isLampOrbiting = false;

}

//function declarations
bool UInitialize(int, char *[], GLFWwindow **window);

void UProcessInput(GLFWwindow *window, unsigned int program);

void UMousePositionCallback(GLFWwindow *window, double xpos, double ypos);

void UMouseScrollCallback(GLFWwindow *window, double xoffset, double yoffset);

void UMouseButtonCallback(GLFWwindow *window, int button, int action, int mods);

void UResizeWindow(GLFWwindow *window, int width, int height);


int main(int argc, char *argv[]) {

    //create glfw window and init glew/glfw
    auto gWindow = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, std::string(WINDOW_TITLE).c_str(), NULL, NULL);
    if (!UInitialize(argc, argv, &gWindow)) {
        return EXIT_FAILURE;
    }

    gCam.MovementSpeed = 0.5f;
    //creating shaders
    auto fragmentShader = shader("./shaders/shader.frag", GL_FRAGMENT_SHADER);
    auto vertexShader = shader("./shaders/shader.vert", GL_VERTEX_SHADER);

    //create program
    auto regularShaderProgramId = glCreateProgram();

    //attach shaders and link
    glAttachShader(regularShaderProgramId, vertexShader.shaderIndex);
    glAttachShader(regularShaderProgramId, fragmentShader.shaderIndex);
    glLinkProgram(regularShaderProgramId);

    //check for linking problems
    auto success = 0;
    auto infoLog = std::array<char, 512>();
    glGetProgramiv(regularShaderProgramId, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(regularShaderProgramId, 512, nullptr, infoLog.data());
        std::cerr << "ERROR::SHADER::PROGRAM::LINK_FAILED\n" << infoLog.data() << std::endl;
        std::exit(-1);
    }


    //use shader program
    glUseProgram(regularShaderProgramId);

    //set texture as texture unit 0
    glUniform1i(glGetUniformLocation(regularShaderProgramId, "uTexture"), 0);

    auto cylinder = model(model::CYLINDER, "./textures/RemoteIRTransmitter.png"); //IR Transmitter at front of remote
    auto box = model(model::BOX, "./textures/Remote.png"); //remote
    auto vape = model(model::BOX, "./textures/vape.png"); //vape
    auto plane = model(model::PLANE, "./textures/Plane.png"); //floor
    auto lamp = model(model::BOX, "./textures/white.png"); //lamp box with blank white textured I made for it
    auto lamp2 = model(model::BOX, "./textures/red.png"); //second light with red texture as this light produces red light
    auto ring = model(model::CYLINDER, "./textures/silver.png"); //ring
    auto bottom = model(model::CYLINDER, "./textures/white.png"); //bottom of lotion bottle
    auto top = model(model::CYLINDER, "./textures/red.png"); //top of lotion bottle

    //lamp shader stuff
    auto lightVertexShader = shader("./shaders/lamp.vert", GL_VERTEX_SHADER);
    auto lightFragShader = shader("./shaders/lamp.frag", GL_FRAGMENT_SHADER);

    auto lampShaderProgramId = glCreateProgram();
    glAttachShader(lampShaderProgramId, lightVertexShader.shaderIndex);
    glAttachShader(lampShaderProgramId, lightFragShader.shaderIndex);
    glLinkProgram(lampShaderProgramId);

    glGetProgramiv(lampShaderProgramId, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(lampShaderProgramId, 512, nullptr, infoLog.data());
        std::cerr << "ERROR::LAMP::SHADER::PROGRAM::LINK_FAILED\n" << infoLog.data() << std::endl;
        std::exit(-1);
    }

    //render loop
    while (!glfwWindowShouldClose(gWindow)) {
        //enable z stuff
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LESS);

        //delta time stuff
        auto currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        //setup new frame
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //poll events
        glfwPollEvents();

        //take input
        UProcessInput(gWindow, regularShaderProgramId);

        //set shader to use
        glUseProgram(regularShaderProgramId);


        // setup scene camera/mvp
        auto modelMatrix = glm::mat4{1.0f};
        auto cameraMatrix = gCam.GetViewMatrix();
        auto projectionMatrix = glm::mat4{1.0f};
        if (viewSwitch == false) {
            projectionMatrix = glm::perspective(glm::radians(gCam.Zoom),
                                                (GLfloat) WINDOW_WIDTH / (GLfloat) WINDOW_HEIGHT, 0.1f, 1000.0f);
        } else {
            projectionMatrix = glm::ortho((double) -1, (double) 1, (double) -1 * (WINDOW_WIDTH / WINDOW_HEIGHT),
                                          (double) 1 * (WINDOW_WIDTH / WINDOW_HEIGHT), -0.1, 1000.0);
        }
        //auto projectionMatrix = glm::perspective(glm::radians(gCam.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);


        auto viewPosUniform = glGetUniformLocation(regularShaderProgramId, "viewPosition");
        auto UVScaleUniform = glGetUniformLocation(regularShaderProgramId, "uvScale");
        auto modelUniform = glGetUniformLocation(regularShaderProgramId, "model");
        auto mvpUniform = glGetUniformLocation(regularShaderProgramId, "mvp");
        auto mvp = projectionMatrix * cameraMatrix * modelMatrix;

        //setup mvp
        glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
        glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));

        const glm::vec3 camPos = gCam.Position;

        //send light1 info to uniforms
        auto light1PosUniform = glGetUniformLocation(regularShaderProgramId, "light1Pos");
        auto light1ColorUniform = glGetUniformLocation(regularShaderProgramId, "light1Color");
        auto object1ColorUniform = glGetUniformLocation(lampShaderProgramId, "object1Color");

        //glUniform3f(object1ColorUniform, objectColor.r, objectColor.g, objectColor.b);
        glUniformMatrix4fv(object1ColorUniform, 1, GL_FALSE, glm::value_ptr(objectColor));
        glUniform3f(light1ColorUniform, lightColor.r, lightColor.g, lightColor.b);
        glUniform3f(light1PosUniform, lightPos.x, lightPos.y, lightPos.z);

        //send light2 info to uniforms
        auto light2PosUniform = glGetUniformLocation(regularShaderProgramId, "light2Pos");
        auto light2ColorUniform = glGetUniformLocation(regularShaderProgramId, "light2Color");
        auto object2ColorUniform = glGetUniformLocation(lampShaderProgramId, "object2Color");

        glUniform3f(object2ColorUniform, object2Color.r, object2Color.g, object2Color.b);
        glUniform3f(light2ColorUniform, light2Color.r, light2Color.g, light2Color.b);
        glUniform3f(light2PosUniform, light2Pos.x, light2Pos.y, light2Pos.z);

        glUniform3f(viewPosUniform, camPos.x, camPos.y, camPos.z);
        glUniform2fv(UVScaleUniform, 1, glm::value_ptr(UVScale));

        {
            // Floor
            modelMatrix = glm::scale(glm::vec3(2.0f, 1, 2.0f));
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0, 0.79f, 0.0f));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;

            plane.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, plane.IndexCount(), GL_UNSIGNED_SHORT, nullptr);
        }


        {
            // Remote Box
            modelMatrix = glm::scale(glm::vec3(2.0f, 0.5, 1.1));
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, 0.6f, 3.0f));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;

            box.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, box.IndexCount(), GL_UNSIGNED_SHORT, nullptr);

            // Remote IR transmitter
            modelMatrix = glm::translate(glm::vec3(-1.75f, 0.3f, 3.3f));
            modelMatrix = glm::rotate(modelMatrix, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
            modelMatrix = glm::scale(modelMatrix, glm::vec3(0.10f, 0.15f, 0.25f));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;

            cylinder.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, cylinder.IndexCount(), GL_UNSIGNED_SHORT, nullptr);
        }

        {
            // Vape Box
            modelMatrix = glm::rotate(glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
            modelMatrix = glm::scale(modelMatrix, glm::vec3(2.0f, 0.5, 1.1));
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0.3f, 0.6f, -3.5f));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;

            vape.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, vape.IndexCount(), GL_UNSIGNED_SHORT, nullptr);
        }

        {
            //ring
            modelMatrix = glm::mat4{ 1.0f };
            modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.1f, 0.5f));
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, -1.8f, 0.0f));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;

            ring.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, ring.IndexCount(), GL_UNSIGNED_SHORT, nullptr);
        }

        {
            //lotion bottle top + bottom
            //bottom
            modelMatrix = glm::mat4{ 1.0f };
            modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5, 0.15, 0.5));
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0, -1.39, -8.5));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;
            
            bottom.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, bottom.IndexCount(), GL_UNSIGNED_SHORT, nullptr);

            //top
            modelMatrix = glm::mat4{ 1.0f };
            modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5, 0.15, 0.5));
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0, 0.70, -8.5));
            mvp = projectionMatrix * cameraMatrix * modelMatrix;

            top.Bind();
            glUniformMatrix4fv(mvpUniform, 1, GL_FALSE, glm::value_ptr(mvp));
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glDrawElements(GL_TRIANGLES, top.IndexCount(), GL_UNSIGNED_SHORT, nullptr);
        }

        {
            //lamp stuff
            glUseProgram(lampShaderProgramId);
            modelMatrix = glm::translate(lightPos);
            modelMatrix = glm::scale(modelMatrix, lightScale);
            modelUniform = glGetUniformLocation(lampShaderProgramId, "model");
            auto viewUniform = glGetUniformLocation(lampShaderProgramId, "view");
            auto projUniform = glGetUniformLocation(lampShaderProgramId, "projection");

            lamp.Bind();
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glUniformMatrix4fv(viewUniform, 1, GL_FALSE, glm::value_ptr(cameraMatrix));
            glUniformMatrix4fv(projUniform, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
            glDrawElements(GL_TRIANGLES, lamp.IndexCount(), GL_UNSIGNED_SHORT, nullptr);

            //lamp2
            modelMatrix = glm::mat4{ 1.0f };
            modelMatrix = glm::scale(modelMatrix, lightScale);
            modelMatrix = glm::translate(modelMatrix, light2Pos);
            
            lamp2.Bind();
            glUniformMatrix4fv(modelUniform, 1, GL_FALSE, glm::value_ptr(modelMatrix));
            glUniformMatrix4fv(viewUniform, 1, GL_FALSE, glm::value_ptr(cameraMatrix));
            glUniformMatrix4fv(projUniform, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
            glDrawElements(GL_TRIANGLES, lamp2.IndexCount(), GL_UNSIGNED_SHORT, nullptr);
        }

        glfwSwapBuffers(gWindow);
    }
}

bool UInitialize(int argc, char *argv[], GLFWwindow **window) {
    //init glfw
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    //glfw window creation
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, std::string(WINDOW_TITLE).c_str(), nullptr, nullptr);
    if (*window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    //capture cursor
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    //glew init
    glewInit();

    //displays gpu opengl version
    std::cout << "INFO: OPENGL VERSION: " << glGetString(GL_VERSION) << std::endl;
    return true;
}

//process input and act accordingly
void UProcessInput(GLFWwindow *window, unsigned int program) {

    static const auto cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
        glfwSetWindowShouldClose(window, true);
    }
    auto cameraOffset = cameraSpeed * gDeltaTime;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        gCam.ProcessKeyboard(BACKWARD, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        gCam.ProcessKeyboard(FORWARD, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        gCam.ProcessKeyboard(LEFT, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        gCam.ProcessKeyboard(RIGHT, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        gCam.ProcessKeyboard(CAMERA_UP, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        gCam.ProcessKeyboard(CAMERA_DOWN, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_F1) == GLFW_PRESS) {
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    }
    if (glfwGetKey(window, GLFW_KEY_F2) == GLFW_PRESS) {
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    }
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        if (viewSwitch) {
            viewSwitch = false;
            std::cout << "Switching to Perspective View." << std::endl;
        } else { std::cout << "Already in Perspective View." << std::endl; }
    }
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
        if (viewSwitch == false) {
            viewSwitch = true;
            std::cout << "Switching to Orthographic View." << std::endl;
        } else { std::cout << "Already in Orthographic View." << std::endl; }
    }
}

//glfw resize window callback
void UResizeWindow(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow *window, double xpos, double ypos) {
    if (FirstMouse) {
        lastX = xpos;
        lastY = ypos;
        FirstMouse = false;
    }

    auto xoffset = xpos - lastX;
    auto yoffset = lastY - ypos; //reveresed since y coords are reversed

    lastX = xpos;
    lastY = ypos;

    gCam.ProcessMouseMovement(xoffset, yoffset);

}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow *window, double xoffset, double yoffset) {
    //gCam.ProcessMouseScroll(yoffset);


    if (yoffset > 0) {
        gCam.MovementSpeed += (yoffset / 10);
        std::cout << "Increasing movement speed by: " << (yoffset / 10) << " | Current speed: " << gCam.MovementSpeed
                  << std::endl;
    }

    if (yoffset < 0) {
        if ((gCam.MovementSpeed += (yoffset / 10)) < 0) {
            gCam.MovementSpeed = 0;
            std::cout << "Cannot decrease movement speed, it is already 0." << std::endl;
        } else {
            gCam.MovementSpeed += (yoffset / 10);
            std::cout << "Decreasing movement speed by: " << (yoffset / 10) << " | Current speed: "
                      << gCam.MovementSpeed << std::endl;
        }
    }
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow *window, int button, int action, int mods) {
    switch (button) {
        case GLFW_MOUSE_BUTTON_LEFT: {
            if (action == GLFW_PRESS)
                std::cout << "Left mouse button pressed" << std::endl;
            else
                std::cout << "Left mouse button released" << std::endl;
        }
            break;

        case GLFW_MOUSE_BUTTON_MIDDLE: {
            if (action == GLFW_PRESS)
                std::cout << "Middle mouse button pressed" << std::endl;
            else
                std::cout << "Middle mouse button released" << std::endl;
        }
            break;

        case GLFW_MOUSE_BUTTON_RIGHT: {
            if (action == GLFW_PRESS)
                std::cout << "Right mouse button pressed" << std::endl;
            else
                std::cout << "Right mouse button released" << std::endl;
        }
            break;

        default:
            std::cout << "Unhandled mouse button event" << std::endl;
            break;
    }
}
