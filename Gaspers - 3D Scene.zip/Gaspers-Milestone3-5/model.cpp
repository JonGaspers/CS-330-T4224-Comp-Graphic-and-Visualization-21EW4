/*
*	Name: Jonathon Gaspers
*	Date: April 16, 2021
*	Course: CS330-T4224
*	Description: This cpp file hold all the mesh generation code. This file has the generation code for each of the objects in the scene,
*	this code will generate each object's indices, vertices, texture coordinates and normals. 
*/
#include "model.h"
#include "stb_image.h"
#include <iostream>
model::model(const model::shape& shape, const char* filename)
{
	auto meshdata = model::_mesh_data();
	switch (shape) {
	case BOX:
		meshdata = _genBox();
		break;
	case CYLINDER:
		meshdata = _genCylinder();
		break;
	case PYRAMID:
		meshdata = _genPyramid();
		break;
	case PLANE:
		meshdata = _genPlane();
		break;
	}
	_indices = meshdata.indices.size();
	glGenVertexArrays(1, &_vao);
	glBindVertexArray(_vao);
	
	// Indices
	glGenBuffers(1, &_vbo[0]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _vbo[0]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned short) * meshdata.indices.size(), meshdata.indices.data(), GL_STATIC_DRAW);

	auto zipped = std::vector<float>();
	zipped.reserve(meshdata.indices.size() + meshdata.vertices.size());

	for (int i = 0; i < meshdata.vertices.size() / 3; i++) {
		zipped.emplace_back(meshdata.vertices[i * 3 + 0]); //x
		zipped.emplace_back(meshdata.vertices[i * 3 + 1]); //y
		zipped.emplace_back(meshdata.vertices[i * 3 + 2]); //z
		zipped.emplace_back(meshdata.texture_coords[i * 2 + 0]); //u
		zipped.emplace_back(meshdata.texture_coords[i * 2 + 1]); //v
		zipped.emplace_back(meshdata.normals[i * 3 + 0]); //x
		zipped.emplace_back(meshdata.normals[i * 3 + 1]); //y
		zipped.emplace_back(meshdata.normals[i * 3 + 2]); //z
	}

	glGenBuffers(1, &_vbo[1]);
	glBindBuffer(GL_ARRAY_BUFFER, _vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * zipped.size(), zipped.data(), GL_STATIC_DRAW);

	GLsizei attribute_size = 8 * sizeof(float); // xyz + uv + 3 for normals
	GLsizei tex_offset = 3 * sizeof(float); //xyz
	GLsizei normal_offset = 5 * sizeof(float); // xyz + uv = 5

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, attribute_size, (void*)(0));
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, attribute_size, (void*)(tex_offset));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, attribute_size, (void*)(normal_offset));
	glEnableVertexAttribArray(2);

	if (filename != nullptr) {
		int width, height, channels;
		stbi_set_flip_vertically_on_load(true);
		unsigned char* image = stbi_load(filename, &width, &height, &channels, 4);
		glGenTextures(1, &_textureHandle);
		glBindTexture(GL_TEXTURE_2D, _textureHandle);
		if (filename == "Plane.png") {
			//set plane.png to GL_MIRRORED_REPEAT
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		}
		else {
			// Set the texture wrapping parameters.
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		}
		
		// Set texture filtering parameters.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
	}

}

model::~model()
{
	glDeleteBuffers(1, &_vao);
	glDeleteBuffers(2, _vbo.data());
	if (_textureHandle != std::numeric_limits<unsigned int>::max()) {
		glDeleteTextures(1, &_textureHandle);
	}
}

void model::Bind() const noexcept
{
	glBindVertexArray(_vao);
	if (_textureHandle != std::numeric_limits<unsigned int>::max()) {
		glBindTexture(GL_TEXTURE_2D, _textureHandle);
	}
}

unsigned int model::IndexCount() const noexcept
{
	return _indices;
}

model::_mesh_data model::_genBox()
{
	auto mesh = model::_mesh_data();

	//data for cube indices
	mesh.indices = {
		//top
		0, 1, 2,
		0, 2, 3,
		//left
		4, 5, 6,
		4, 6, 7,
		//right
		8, 9, 10,
		8, 10, 11,
		//bottom
		12, 13, 14,
		12, 14, 15,
		//front?
		16, 17, 18,
		16, 18, 19,
		//back?
		20, 21, 22,
		20, 22, 23
	};

	mesh.vertices = {
			//top
			-1.0f, 1.0f, 1.0f,
			-1.0f, 1.0f, -1.0f,
			1.0f, 1.0f, -1.0f,
			1.0f, 1.0f, 1.0f,

			//left
			-1.0f, 1.0f, 1.0f,
			-1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,
			1.0f, 1.0f, 1.0f,

			//right
			-1.0f, 1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f,
			1.0f, 1.0f, -1.0f,

			//bottom
			-1.0f, -1.0f, 1.0f,
			-1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, 1.0f,

			//front
			-1.0f, 1.0f, 1.0f,
			-1.0f, -1.0f, 1.0f,
			-1.0f, -1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,

			//back
			1.0f, 1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, -1.0f,
			1.0f, 1.0f, -1.0f
	};

	mesh.texture_coords = {
		//top
			0.5f, 1.0f,
			0.0f, 1.0f,
			0.0f, 0.66666666f,
			0.5f, 0.66666666f,
		//left
			0.0f, 0.66666666f,
			0.5f, 0.66666666f,
			0.5f, 0.33333333f,
			0.0f, 0.33333333f,
		//right
			0.5f, 1.0f, 
			1.0f, 1.0f,
			1.0f, 0.66666666f,
			0.5f, 0.66666666f,
		//bottom
			0.5f, 0.66666666f,
			1.0f, 0.66666666f,
			1.0f, 0.33333333f,
			0.5f, 0.33333333f,
		//front?
			0.0f, 0.33333333f,
			0.5f, 0.33333333f,
			0.5f, 0.0f,
			0.0f, 0.0f,
		//back?
			0.5f, 0.3333333f,
			1.0f, 0.3333333f,
			1.0f, 0.0f,
			0.5f, 0.0f
			
	};

	mesh.normals = {
		//top
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		//left
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		//right
        0.0f, 0.0f, -1.0f,
        0.0f, 0.0f, -1.0f,
        0.0f, 0.0f, -1.0f,
        0.0f, 0.0f, -1.0f,
		//bottom
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		//front
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		//back
		-1.0f, 0.0, 0.0,
		-1.0f, 0.0, 0.0,
		-1.0f, 0.0, 0.0,
		-1.0f, 0.0, 0.0,
	};
	return mesh;
}

model::_mesh_data model::_genCylinder()
{
	constexpr auto PI = 3.1415926f;
	constexpr auto E = 2.71828f;
	auto mesh = model::_mesh_data();

	//gen bottom disc indices
	for (auto i = 0; i <= 120; i++) {
		mesh.indices.push_back(0);
		mesh.indices.push_back(i);
		mesh.indices.push_back(i + 1);
	}

	//gen top disc vertices
	for (auto i = 122; i <= 122 + 120; i++) {
		mesh.indices.push_back(122);
		mesh.indices.push_back(i);
		mesh.indices.push_back(i + 1);
	}

	//gen side mesh.indices
	for (auto i = 1; i <= 120; i++) {
		auto top = i + 121;
		auto nextVertex = i + 1;
		if (i == 120) {
			nextVertex = 1;
		}
		mesh.indices.push_back(i);
		mesh.indices.push_back(nextVertex);
		mesh.indices.push_back(nextVertex + 121);
		mesh.indices.push_back(nextVertex + 121);
		mesh.indices.push_back(i);
		mesh.indices.push_back(top);
	}

	//gen bottom disc vertices
	for (int i = 0; i < 3; i++)
		mesh.vertices.emplace_back(0.0f);

	for (int i = 120; i >= 0; i--) {
		mesh.vertices.push_back(std::cos(i * PI * 2 / 120.0f));
		mesh.vertices.push_back(0);
		mesh.vertices.push_back(std::sin(i * PI * 2 / 120.0f));
	}

	mesh.vertices.emplace_back(0.0f);
	mesh.vertices.emplace_back(2.0f);
	mesh.vertices.emplace_back(0.0f);

	for (int i = 120; i >= 0; i--) {
		mesh.vertices.push_back(std::cos(i * PI * 2 / 120.0f));
		mesh.vertices.push_back(2);
		mesh.vertices.push_back(std::sin(i * PI * 2 / 120.0f));
	}

	// Generate the UV coordinates (just 0's)
	mesh.texture_coords.resize((mesh.vertices.size() / 3) * 2, 0);
	//center vertex uv
	mesh.texture_coords[121 * 2 + 0] = 0.5f;
	mesh.texture_coords[121 * 2 + 1] = 0.5f;

	for (auto i = 122; i <= 122 + 120; i++) {
		mesh.texture_coords[i * 2 + 0] = std::cos(i * PI / 120.0f) * 0.5 + 0.5f;
		mesh.texture_coords[i * 2 + 1] = 0.5f - std::sin(i * PI / 120.0f) * 0.5f;
		std::cout << "U: " << std::cos(i * PI / 120.f) * 0.5 + 0.5f << ", V: " << 0.5f - std::sin(i * PI / 120.f) * 0.5f << std::endl;
		/*std::cout << "U: " << (1/(1 + std::pow(E, -(std::cos(i * PI / 120.0f) + 0.5f)) <<*/ 
	}

	//set normals to 0, no reflect?
	mesh.normals.resize((mesh.vertices.size() / 3) * 3, 0.1);
	return mesh;
}

model::_mesh_data model::_genPyramid()
{
	auto mesh = model::_mesh_data();

	// Pyramid Indices
	mesh.indices = {
			0, 1, 2,
			0, 2, 3,
			0, 3, 4,
			0, 4, 1,
			1, 2, 3,
			1, 3, 4
	};

	// Pyramid Vertices
	mesh.vertices = {
			0.0f, 1.0f, 0.0f,
			-1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, 1.0f,
			-1.0f, -1.0f, 1.0f,
	};

	// Generate the UV coordinates (just 0's)
	mesh.texture_coords.resize((mesh.vertices.size() / 3) * 2, 0);

	mesh.normals = {
		//left
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		//right
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		//bottom
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		//front
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		//back
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f
	};

	return mesh;
}

model::_mesh_data model::_genPlane()
{
	auto mesh = model::_mesh_data();

	mesh.indices = {
		0, 1, 2,
		0, 3, 2
	};

	mesh.vertices = {
		-10.0, -1.0f, -10.0f,
		10.0, -1.0f, -10.0f,
		10.0, -1.0f, 10.0f,
		-10.0, -1.0f, 10.0f
	};

	mesh.texture_coords = {
		0.0f, 10.0f,
		10.0f, 10.0f,
		10.0f, 0.0f,
		0.0f, 0.0f
	};

	mesh.normals = {
		//top
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f
	};

	

	return mesh;
}

model::_mesh_data model::_genLightBox() {
	auto mesh = model::_mesh_data();

	//data for cube indices
	mesh.indices = {
		//top
		0, 1, 2,
		0, 2, 3,
		//left
		4, 5, 6,
		4, 6, 7,
		//right
		8, 9, 10,
		8, 10, 11,
		//bottom
		12, 13, 14,
		12, 14, 15,
		//front?
		16, 17, 18,
		16, 18, 19,
		//back?
		20, 21, 22,
		20, 22, 23
	};

	mesh.vertices = {
		//top
		-1.0f, 1.0f, 1.0f,
		-1.0f, 1.0f, -1.0f,
		1.0f, 1.0f, -1.0f,
		1.0f, 1.0f, 1.0f,

		//left
		-1.0f, 1.0f, 1.0f,
		-1.0f, -1.0f, 1.0f,
		1.0f, -1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,

		//right
		-1.0f, 1.0f, -1.0f,
		-1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, 1.0f, -1.0f,

		//bottom
		-1.0f, -1.0f, 1.0f,
		-1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, 1.0f,

		//front
		-1.0f, 1.0f, 1.0f,
		-1.0f, -1.0f, 1.0f,
		-1.0f, -1.0f, -1.0f,
		-1.0f, 1.0f, -1.0f,

		//back
		1.0f, 1.0f, 1.0f,
		1.0f, -1.0f, 1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, 1.0f, -1.0f
	};

	mesh.texture_coords = {
			//top
			0.5f, 1.0f,
			0.0f, 1.0f,
			0.0f, 0.66666666f,
			0.5f, 0.66666666f,
			//left
			0.0f, 0.66666666f,
			0.5f, 0.66666666f,
			0.5f, 0.33333333f,
			0.0f, 0.33333333f,
			//right
			0.5f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.66666666f,
			0.5f, 0.66666666f,
			//bottom
			0.5f, 0.66666666f,
			1.0f, 0.66666666f,
			1.0f, 0.33333333f,
			0.5f, 0.33333333f,
			//front?
			0.0f, 0.33333333f,
			0.5f, 0.33333333f,
			0.5f, 0.0f,
			0.0f, 0.0f,
			//back?
			0.5f, 0.3333333f,
			1.0f, 0.3333333f,
			1.0f, 0.0f,
			0.5f, 0.0f

	};

	mesh.normals = {
		//top
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		//left
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		//right
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		//bottom
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		//front
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		//back
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f
	}; 
	return mesh;
}