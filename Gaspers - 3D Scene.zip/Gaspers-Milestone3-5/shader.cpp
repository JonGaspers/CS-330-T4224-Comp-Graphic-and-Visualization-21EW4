/*
*   Name: Jonathon Gaspers
*   Date: April 16, 2021
*   Course: CS330-T4224
*   Description: This cpp file holds all the code related to loading shader files and compiling them.
*/

#include "shader.h"


shader::shader(const std::string& filename, GLuint shaderType) {
	auto filestream = std::ifstream(filename);
	auto shaderSource = std::string(std::istreambuf_iterator<char>(filestream), std::istreambuf_iterator<char>());
	//std::cout << shaderSource << std::endl;
	shaderIndex = glCreateShader(shaderType);

	auto success = 0;
	auto infoLog = std::array<char, 512>();

	const auto shaderSourcePtr = shaderSource.c_str();

	glShaderSource(shaderIndex, 1, &shaderSourcePtr, nullptr);
	glCompileShader(shaderIndex);

	glGetShaderiv(shaderIndex, GL_COMPILE_STATUS, &success);
	if (!success) {
		glGetShaderInfoLog(shaderIndex, 512, nullptr, infoLog.data());
		std::cerr << "ERROR::SHADER::" << filename << "::COMPILATION_FAILED\n" << infoLog.data() << std::endl;
		std::exit(-1);
	}

}