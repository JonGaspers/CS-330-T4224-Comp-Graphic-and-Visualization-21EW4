#pragma once
#include <array>
#include <vector>
#include <GL/glew.h>
#include <cmath>
class model
{
public:
	enum shape {
		BOX,
		CYLINDER,
		PYRAMID,
		PLANE,
		LIGHTBOX
	};

	model(const model::shape& shape, const char* filename = nullptr);

	~model();

	void Bind() const noexcept;
	[[nodiscard]]unsigned int IndexCount() const noexcept;

private:
	unsigned int _vao; 
	std::array<unsigned int, 2> _vbo;
	unsigned int _textureHandle = std::numeric_limits<unsigned int>::max();
	unsigned int _indices;
	struct _mesh_data {
		std::vector<unsigned short> indices;
		std::vector<float> vertices;
		std::vector<float> texture_coords;
		std::vector<float> normals;
	};

	[[nodiscard]] static model::_mesh_data _genBox();
	[[nodiscard]] static model::_mesh_data _genCylinder();
	[[nodiscard]] static model::_mesh_data _genPyramid();
	[[nodiscard]] static model::_mesh_data _genPlane();
	[[nodiscard]] static model::_mesh_data _genLightBox();
};

